
public class SavingsAccount extends BaseAccount { //additional to base account

	final String acctType = "Savings Account"; //final = not changeable at runtime
	
	/**
     * A constructor, this creates a savings account object which is extended from baseAccount.<br>
     * Uses same variables as the baseAccount but with some different methods.
     * @param name The owner's name to used in conjunction with the account.
     */
	protected SavingsAccount(String name) {
		super(name); 	//generate with 0 balance
	}

	/**
     * A method, Allows an amount to to deposited into the account.<br>
     * The amount must above zero.
     * @param amount The deposit amount to go into the the bank account.
     * @return true: only if the amount is positive.
     */
	@Override //implement deposit as dictated by base account
	public boolean deposit(double amount) {
		if (amount > 0){	//is the amount positive?
			this.balance = this.balance + amount;	//increase balance
			return true;
		}
		return false; //false if the statements exited earlier indicating transaction failed
	}

	/**
     * Method, Gives the availability of an amount to be withdrawn from the account.<br>
     * The amount will have to be above zero.
     * @param amount The withdrawal amount to go out of the account.
     * @return true: When the amount is positive.
     */
	public boolean withdraw(double amount) {
		if (amount > 0){	//must be positive
			if (this.balance >= amount){ //does the balance have enough funds?
				this.balance = this.balance - amount;	//remove funds
				return true;
			}
		}
		return false; //false if this is reached
	} 
	
	/**
     * Adds interest to an account according the rate passed to this. The rate must be a double, positive and be expressed as whole amount.<br>
     * For example, for 5% interest, you pass "5" and this function will auto change it to 0.05 for calculation.
     * @param rate the percentage as a whole to be added to the account.
     * @return true: If the rate is above zero.
     */
	public boolean addInterest(double rate) {
		if (rate > 0) { //interest must be positive
			rate = rate / 100;	//input is 8.0 so we convert to 0.08, as this is the percentage used in calculation.
			this.balance = this.balance + (this.balance * rate);	//increase balance by the rate
			return true;
		}
		return false; //false if this is reached
	}
	
	/**
     * Creates String representation of the Savings Account, overrides Object's toString, is invoked by statements such as "println".<br>
     * It builds on baseAccount (name, account number and balance) but adds Account Type and the output has 2 Tabs (\t) in-between.
     * @return state: a String of the account's State. Specific variables are listed above.
     */
	@Override //override base account so we can add account type, since base account won't know.
	public String toString()
    {
		String state = super.toString(); 	//use base account toString
    	state = state + "\t\t" + acctType;	//now we add the account type with 2 Tabs
		return state; 
	}
}
