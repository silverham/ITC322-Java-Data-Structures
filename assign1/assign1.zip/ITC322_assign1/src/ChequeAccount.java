/**
 * An concrete class that extends basic Bank Account with variations for a cheque account
 */
public class ChequeAccount extends BaseAccount { //adds on from base account

	private double creditLimit;	//a credit limit that can only be changed by this class
	final double charge = 0.3; //30c transaction charge, final means it cannot be changed
	final String acctType = "Cheque Account"; 
	
	/**
     * A Constructor, that makes cheque account, building off baseAccount.<br>
     * This can be used directly. Also creates a credit limit with default zero.
     * @param name Owner's name
     */
	protected ChequeAccount(String name) {
		super(name); //create a base account first by a call to it's parent, baseAccount
		creditLimit = 0; //generate with 0 balance
	}
	
	/**
     * Changes the credit limit for which the account can overdrawn.<br>
     * Must be a positive amount
     * @param limit The credit limit to be changed to.
     * @return true If limit is zero or positive.
     */
	public boolean setCreditLimit(double limit){
		if (limit >= 0) {	//proposed limit must be positive or zero.
			creditLimit = limit;
			return true;
		}
		return false;	//negative limit, return false
	}
	
	/**
     * Deposits money into account. The amount put in must be not only positive but also has to be more than the transaction charge when account has low balance.<br>
     * For example, You cannot deposit 20c when the balance is 0, as this will leave account overdrawn by 10c.
     * @param amount The amount to money to added to account, must be positive.
     * @return true: if the described conditions are met, otherwise false.
     */
	@Override //implement deposit due to force (it's in base account as abstract).
	public boolean deposit(double amount) {
		if (amount > (0 + charge)){ //must be positive and above charge rate.
			this.balance = this.balance + (amount - charge); //"this" is the current object and the deposited amount is less due to charge.
			return true;
		}
		return false; //if statement not true, transaction failed
	}
	
	/**
     * Withdraws money from the account.the amount must be positive and not leave the account overdrawn as result of the transaction charge.<br>
     * For example, with a balance of 50c and try to withdraw 30c, this will not work the account will overdrawn by 10c
     * @param amount The amount to money to withdrawn from account.
     * @return true: If the described conditions are met, otherwise false.
     */
	public boolean withdraw(double amount) {
		if (amount > 0) { //must be positive
			if (this.balance > (amount + charge)){ //must be above charge rate and amount
				this.balance = this.balance - (amount + charge); //amount withdrawal is more due to charge
				return true;
			}
		}
		//if statement(s) false, failed transaction
		return false;
	}
	
	/**
     * Provides a String representation of the account. This is done by overriding Object's toString method.<br>
     * This is then invoked by statements, such as "println".
     * @return state: this is combination of baseAccount's toString (name, account number and balance) with account type and credit limit, split by 2 Tabs (\t).
     */
	@Override //override object class toString for our representation in println
	public String toString()
    {
		String state = super.toString(); 	//use base account toString
    	state = state + "\t\t" + acctType + "\t\t$" + String.format("%.2f", creditLimit);	//now add on the type and credit limit due to being a cheque account
		return state; 
	}
}
