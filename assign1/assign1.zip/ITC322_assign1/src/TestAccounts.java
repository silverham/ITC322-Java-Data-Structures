import java.util.Arrays; //used in arrays.sort() later

/**
 * This class tests the account classes of a base account and it's associated Cheque and Savings accounts.
 */
public class TestAccounts
{
	/**
	 * The program is executed from here, the "main" method.
	 */
    public static void main(String[] args)
    {
        //Account[] list = new Account[5]			// if base account was called "accounts" we would use this
    	BaseAccount[] list = new BaseAccount[5];	//but it is not, assuming a spelling mistake (correct me i'm wrong though, thanks)

        list[0] = new SavingsAccount("Fred");		//make some test accounts
        list[1] = new ChequeAccount("Jim");
        list[2] = new ChequeAccount("Sue");
        list[3] = new SavingsAccount("Jim");
        list[4] = new SavingsAccount("Jill");

        int i;			//i for the loops, result is for the output of the operations
        Boolean result;

        System.out.println("Setting 50.0 credit limit:\n");	// \n is newline marker, \t is tab
        System.out.println("Worked \t Name \t Account Number \t Balance \t Account Type \t Credit Limt (where applicable)");
        
        for (i = 0; i < 5; i++) {
        	if (list[i] instanceof ChequeAccount) {	//check if we can do this operation by checking the object type
        		ChequeAccount tempAccount = (ChequeAccount)list[i]; //create temp account the right account type (cast)
        		result = tempAccount.setCreditLimit(50.0);			//do operation, temp does not need to changed back in the list since java passes objects by reference	
        		System.out.print(result + " \t ");					//this first column, indicating success
        	}
        	else {
        		System.out.print("false \t ");	//no success
        	}
            System.out.println(list[i]);	//output out the account details
        }
        
        System.out.println("\nDepositing 20.0:\n");
        System.out.println("Worked \t Name \t Account Number \t Balance \t Account Type \t Credit Limt (where applicable)");

        for (i = 0; i < 5; i++) {
        	result = list[i].deposit(20.0);	//all accounts have deposit method, no casting required
        	System.out.print(result + " \t ");	//output the results + details
            System.out.println(list[i]);
        }

        System.out.println("\nWithdrawing 25.0:\n");
        System.out.println("Worked \t Name \t Account Number \t Balance \t Account Type \t Credit Limt (where applicable)");
        
        for (i = 0; i < 5; i++) {
        	double amount = 25.0;	//used twice, set amount here once
        	
        	if (list[i] instanceof ChequeAccount) { 				//check object is right type, two if statements required as they are different accounts
        		ChequeAccount tempAccount = (ChequeAccount)list[i];	//Others may be made in future that do not allow withdrawal eg homeloans
        		result = tempAccount.withdraw(amount);	//cast, get result and then print
        		System.out.print(result + " \t ");
        	}
        	else {	//if not one type, now check the other
        		if ((list[i] instanceof SavingsAccount)){	//same as above, check type, cast, withdraw and output
        			SavingsAccount tempAccount = (SavingsAccount)list[i];
        			result = tempAccount.withdraw(amount);
        			System.out.print(result + " \t ");
        		}
        		else {
        			System.out.print("false \t ");	//its neither account type
        		}
        	}
            System.out.println(list[i]);
        }

        System.out.println("\nAdding 8.0% interest:\n");
        System.out.println("Worked \t Name \t Account Number \t Balance \t Account Type \t Credit Limt (where applicable)");
        
        for (i = 0; i < 5; i++) {
        	if ((list[i] instanceof SavingsAccount)){	//check account type
        		SavingsAccount tempAccount = (SavingsAccount)list[i];	//cast, so no compile error happens
        		result = tempAccount.addInterest(8.0);	//add interest
        		System.out.print(result + " \t ");
        	}
        	else {
        		System.out.print("false \t ");
        	}
            System.out.println(list[i]);
        }

        System.out.println("\nSorting by name:\n");
        System.out.println("Name \t Account Number \t Balance \t Account Type \t Credit Limt (where applicable)");
        
        
        for (i = 0; i < 5; i++){
        	Arrays.sort(list);	//using overridden compareTo so we can now sort by the names
            System.out.println(list[i]);
        }
    }
}

        
