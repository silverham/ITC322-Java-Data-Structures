/**
 * This an abstract class to represent a basic Bank Account.<br>
 * It cannot be used directly, only by instantiating it  though a concrete class, such as ChequeAccount, can it be used.
 */
public abstract class BaseAccount
    implements Comparable<BaseAccount>{		//by using Comparable, we use other java classes such as Arrays.sort to compare
    
	private static int nextAcctNumber = 1;	//these are the core variables to all the accounts
    protected String owner;					//private = can only be accessing by this class
    protected int acctNumber;				//protected can accessed from anything in this package and other packages via subclasses eg inheritance
    protected double balance;

    /**
     * This Constructor will only be used by the sub-classes as it is abstract.<br>
     * It creates a uniquely incremented account number and with a balance of zero.
     * @param name The name to be used by owner.
     */
    
    protected BaseAccount(String name) { 	//The constructor for creating a base account through another class
        owner = name;						//These are the variables for this object/BaseAccount
        acctNumber = nextAcctNumber++;		//Increment each account number so each is unique
        balance = 0.0;
    }

    /**
     * Makes a deposit. all implementations check amount is positive, along with other things.<br>
     * The implementations differs in sub-classes, so no method provided here, but it must be implemented in sub-classes.
     * @param amount the amount to be deposited
     * @return true: only if the amount is not negative
     */
    public abstract boolean deposit(double amount);
    
    /**
     * Compares accounts by owner's name and is part of the implementation of comparable.<br>
     * This Also Uses string object's compareTo.
     * @param rhs (Right Hand Side), the account being compared to
     * @return a number: 1 is higher, 0 is equal, -1 is lower
     */
    @Override //tells complier to check if this method if overriding another, in this case, it's overriding a method in the comparable interface.
    public int compareTo(BaseAccount rhs){
    	return owner.compareTo(rhs.owner);
    }
    
    /**
     * Compares accounts by owner (name) by checking if they are "equal", uses String's equals method.
     * @param rhs (Right Hand Side of type Object), the account being checked against for equality.
     * @return A boolean, true if same owner, false if not.
     */
    @Override //make sure the bank account is compared by name, to be consistent with compareTo
    public boolean equals(Object rhs){	
    	BaseAccount test = (BaseAccount)rhs;	//cast to object to baseaccount for processing
    	return owner.equals(test.owner); }		//use string object's equals

   /**
    * Represents an account's State by the use of a string.<br>
    * Overrides Object's toString and is invoked by statements such as "println".
    * @return state, owner, account number, and balance (2 decimal place), all separated by 2 tabs (\t).
    */
    @Override	//force compiler to check of if it is overriding
    public String toString(){
    	// \t is a insert tab, $ is there for the currency symbol and string.format rounds to 2 decimal places.
    	String state = owner + "\t\t" + acctNumber + "\t\t$" + String.format("%.2f", balance);
		return state;  
		}
}
