/*Assignment 2 - ITC-322
 * By Joshua Graham 11490893
 * This program is is designed to compute various aspects of polynomials
 * by testing a students ability and use of Java data structures
*/
import java.io.File;					//These two are used in file operations
import java.io.FileNotFoundException;
import java.util.Collections;			//Collections and linkedlist are imported to allow there use such as the arrays.sort.
import java.util.LinkedList;
import java.util.Scanner;				//scanner is used when getting input from user

/**This class called Node is used to house the two fields used that the later class for a linked list.
 * @author Joshua Graham
 */

class Node  implements Comparable<Node>{ //node is compared directly
	int num1;	//Field 1 and 2
	int num2;
	/** A Constructor to facilitate an empty node for adding later. */
	Node(){}
	/** A Constructor to create node used in the linked list of polynomial. 
	 * @param num1
	 * 	A integer for first field (Number of x's)
	 * @param num2
	 * 	A integer for second field (x to the power of this number)
	 */
	Node (int num1, int num2){
		this.num1 = num1;	//a constructor so that two set commands are not necessary
		this.num2 = num2;
	}
	/** 
	 * Overrides Object's toString, is used to deliver visual output of the node as called by System.out.println 
	 * @return
	 *	Returns the node's two fields separated by a space 
	 */
	@Override
	public String toString(){
		return(num1 + " " + num2); //the two fields separated by a space
	}
	/** 
	 * Implementing comparable, compareTo is used by each number internally by collections.sort
	 * @return
	 *	-1, 0, 1 - depending on if the right hand side is less, equal or more
	 */
	public int compareTo(Node rhs) {	//implemented function of comparable, reversed implementation of the normal equals function in descending order.
		if (this.num2 > rhs.num2){	//sorted by power (num2), if num2 is higher -1
			return -1;
		}else {
			if (this.num2 < rhs.num2){	//if num2 is less 1
				return 1;
			} else {
				return 0;	//otherwise, it is equal 0
			}
		}
	}
}

/**
 * Polynomials  is a extension of linked list that provides extra functions specific to polynomials.<br>
 * The custom implementation involves the use of class "Node" to provide two fields in each node instead of one. 
 * @author Joshua Graham
 */

public class Polynomials extends LinkedList<Node>{
	private static final long serialVersionUID = 1L; //avoid Eclipse error, only used directly in serializable objects.
	
	/**
     * A method that makes a call to the polynomial constructor by reading the polynomial from a file using the location in the string first
     * @param fileName
     * 	The file name or file path + file name to the fileName of the text document.
     * @precondition
     * 	The text document must have only one term in each line and no plus signs.
     * @postcondition
     * 	A sorted polynomial linked list is created.
     * @throws NumberFormatException
     * 	An indicator that the file could not be read, possible cause is that it does not exist or is in the wrong location.
     */
	private static Polynomials readPolynomialsFile (String fileName){
		String polyString = "";	//the string used to create the polynomial at the end
		String tempString;		//input from user
		boolean firstPoly = true;
		try {
			File myFile = new File(fileName);		//create the objects to get file input
	        Scanner myScanner = new Scanner(myFile);
	        while (myScanner.hasNextLine()) {		//while there are lines to read
	        	tempString = myScanner.nextLine();	//grab the line
	        	if (!tempString.substring(0, 1).equals("-")){	//does first character have minus? if not then make a plus to separate the nominials
	        		if (firstPoly == false) {					//first term won't have a plus
	        			polyString = polyString.concat("+");	//concat appends strings together
	        		}
	        		firstPoly = false;
	        	}	
	        	polyString = polyString.concat(tempString);
	        }
	        myScanner.close();	//shutdown the resources used for file reading
		} catch (FileNotFoundException e) {
			throw new NumberFormatException("A File error occured. Does it exist? \n" + e);	//throw a error and admit it may happen
		}
		return (new Polynomials(polyString));	//create a polynomial with the string made from the file
	}
	
	/**
     * A method that combines two polynomials, resulting in a product. (each terms times the other polynomial's terms).
     * @param tempPoly1
     * 	The first polynomial to be used.
     * @param tempPoly2
     * 	The second polynomial to be used.
     * @return
     * 	A huge sorted polynomial linked list is created and returned.
     */
	
	static Polynomials productOf (Polynomials tempPoly1, Polynomials tempPoly2){ //times the two polynomials together for a big one
		int tempNum1, tempNum2 = 0;
		Polynomials result = new Polynomials();
		for (int i = 0; i < tempPoly1.size(); i++){							//for each term on this poly and other poly, we multiply together
			for (int i2 = 0; i2 < tempPoly2.size(); i2++){
				tempNum1 = tempPoly1.get(i).num1 * tempPoly2.get(i2).num1;	//algebra is multiplied as usual
				tempNum2 = tempPoly1.get(i).num2 + tempPoly2.get(i2).num2;	//powers are added when multiplied
				result.add(new Node(tempNum1, tempNum2));					//construct the node and add it on to result
			}
		}
		result.addUpTermsAndSort();											//compulsory adding of terms and sorting it
		return result;
	}
	
	/** A Constructor to formulate an empty linked list for future use of polynomials */
	public Polynomials() {}	//used to create an empty list that is added to.
	
	/**
     * A Constructor used to formulate the linked list by the String input of a polynomial.<br>
     * This constructs a linked list like so: 2x3+4x3 = [2 3, 4 3].
     * @param input
     * 	The polynomial passed, in form 2x3+3x2-43x2, the first is such that 2x is to the power of 3 etc.
     * @precondition
     * 	The polynomial string must not contain strange characters such as spaces and other symbols.
     * @postcondition
     * 	A sorted polynomial linked list is created.
     * @throws NumberFormatException
     * 	This shows that a strange character has been passed to the constructor.
     */
	
	public Polynomials(String input) {
		super();	//create normal linked list first then extend
		boolean negative = false;	//some variables used, negative is used for negative numbers, fieldNum tells us which field to input the number
		int fieldNum = 1;
		int length = input.length();	//input.length is used alot, we put into a variable to increase speed so dynamic computing is not needed
		String letter = null;			//letter has similar reason
		Node mynode = new Node();		//blank node to be added to at different times
		int numset = 0; 				//which num has been recently set, It is different to fieldNum which tells us which is "to be" set and other is "has been" set
		for(int i = 0; i <= length ; i++) {	//loop entire string, <= is used so we can tell if we are at end.
			if ( i != length) { 								//if we are not at the end 
				letter = input.substring(i, i + 1);				//grab this and next number
				if (letter.equals("+") || letter.equals("-")) {	//+ or -
						add(mynode);			//add the collected terms, as noted by the + and - separators
						fieldNum = 1;			//reset variables, start another node etc.
						mynode = new Node(); 
						numset = 0;
						negative = false;
					if (letter.equals("-")) {
						negative = true; 		//next number will be negative
					} 
				}else { 						//letter is a "x" or "number"
					if (letter.equals("x")){
						if (mynode.num1 == 0){ 	//x is by it-self is counted as a 1
							mynode.num1 = 1;
						}
						if (mynode.num2 == 0){ 	//no power means 1 power. This is also run twice, another at the end
							mynode.num2 = 1;
						}
						negative = false;		//reset variables for fieldNum2
						fieldNum = 2;
					} else { 					//letter should be a number
						int number = 0;
						try {
							number = Integer.parseInt(letter);	//convert to number and catch bad characters
						} catch (NumberFormatException  e){
							throw new NumberFormatException("Invalid character! Spaces and other characters cannot be used.\n" + e);
						}	
						if (negative == true){
							number = -number; 					//turn into a negative number
						}
						if (fieldNum == 1){
							if (numset == 1){					//if still doing fieldNum then it must be a double digit(or more) number
								mynode.num1 = Integer.parseInt(Integer.toString(mynode.num1).concat(Integer.toString(number))); //combine the strings and convert to a number
							} else {
								mynode.num1 = number;
							}
							numset = 1;							//the first number has just been set
						} else{
							if (numset == 2){					//must be double digit, we support that here for fieldNum2
								mynode.num2 = Integer.parseInt(Integer.toString(mynode.num2).concat(Integer.toString(number)));
							} else {
							mynode.num2 = number;
							}
							numset = 2; 						//the second number has been set
					}
					}
				}
			} else { 									//we are at the end
				if (fieldNum == 2 && mynode.num2 == 0){	//we are at second field but has not been set, so it is 1. 
					mynode.num2 = 1; 					//thus nothing after x, no powers, then is a power of 1 but hidden.
				}
				add(mynode);							//add the node on.
			}
		}
		addUpTermsAndSort();							// add the same powers together and sort as per convention
	}

	/**
     * A function of polynomial that returns a value, given a value of x to calculate with.
     * @param x
     * 	An integer used for x, the first field in the linked list.
     * @return
     * 	The value of the polynomial, in relation to value of x, is returned.
     */
	
	int getValue (int x){
		int total = 0;							//variables for looping and adding to get the total
		int i = 0;
		while (i < this.size()){				//this.size if the number of nodes in linked list
			if (this.get(i).num2 == 0){
				total += (this.get(i).num1 * 1);//anything to the power of 0 is 1
			} else {
				total += (this.get(i).num1 * x) * this.get(i).num2;	//the calculation e.g. 2x3 = (2*2) *3, which is 12
			}
			i++;	//increment the loop
		}
		return total;
	}
	
	/**
     * A function that is used internally by other methods and functions to return a polynomial with no two of same power, also sorts the list.
     * @postcondition
     * 	A sorted polynomial linked list with no two of the same 2nd field (powers).
     */
	
	private void addUpTermsAndSort () { 
		Collections.sort(this); //input must be sorted
		int i = 0;				//loop variables
		int tempNum2;
		boolean samePower = true;
		while (i < this.size()){			//loop works by grouping/sorting powers, getting total then deleting all bar one. then move to next different power.
			tempNum2 = this.get(i).num2;	//get the power
			while (samePower == true) {
				if ((i + 1) != this.size()) { 						//if next term  is available
					if (tempNum2 == this.get(i + 1).num2){ 			//if the next term's power is the same
						this.get(i).num1 += this.get(i + 1).num1;	//add to total, the power
						this.remove(i + 1);							//remove the extra power
					} else {
						samePower = false;	//not the same power so on to the next term in outer loop
					}
				} else {
					return; 				//exit while loop, there are no items left

				}
			}
			samePower = true;	//we are on outer loop, now are to group and count again
			i++; //loop through linked list
		}
	}
	
	/**
     * A function that combines itself and another polynomial together to a separate polynomial, also adds and sorts.
     * @param tempPoly
     * 	A polynomial already created by this program
     * @return
     * 	A bigger sorted polynomial linked list is created and returned
     */
	
	Polynomials add (Polynomials tempPoly){
		Polynomials result = new Polynomials();	//create an empty polynomial
		result.addAll(this);					//add itself and other polynomial
		result.addAll(tempPoly);
		result.addUpTermsAndSort();				//addition of terms and sorting, then return result
		return result;
	}
	
	/**
     * A function that inserts a term into the polynomial then adds and sorts.
     * @param term
     * 	A term in string format to be constructed in into a polynomial.
     * @precondition
     * 	The term must be able to be converted in a polynomial.
     * @return
     * 	A slightly bigger sorted polynomial linked list (it-self) is returned.
     */
	
	Polynomials insertTerm (String term){
		Polynomials tempPoly = new Polynomials(term);	//construct polynomial from the single/multiple terms
		this.addAll(tempPoly);							//add term to itself, sort, adds up terms and return itself
		this.addUpTermsAndSort();
		return this;
	}

	/**
     * A function that derives the a different polynomial from the input one using a formula:  ax^k = kax^k-1
     * @return
     * 	A different polynomial is returned according to formula.
     */
	
	Polynomials getDerivative(){ 							//formula = ax^k = kax^k-1
		int tempNum1, tempNum2 = 0;
		Polynomials result = new Polynomials();
		for (int i = 0; i < this.size(); i++){
			tempNum1 = this.get(i).num1 * this.get(i).num2;	//k (the power) is multiplied by x
			tempNum2 = this.get(i).num2 - 1;				//k is also has 1 taken away
			result.add(new Node(tempNum1, tempNum2));		//add to result at end of loop
		}
		result.addUpTermsAndSort();							//standard adding and sorting
		return result;
	}
	
	/**
     * The Start of the program. It is designed to test drive all of the methods and functions specified in the assignment.<br>
     * This is driven through a small menu to select built-in or user created polynomial.<br>
     * The presentation is of the result on the left and description on the right.<br>
     */
	
	public static void main(String[] args) {
		System.out.println("Welcome to Polynomial Calculator - By Joshua Graham - 11490893 -  ITC322 - Assignment 2");	//title
		Scanner myInput = new Scanner(System.in);
		Polynomials poly = new Polynomials();					//create a blank poly so we choose which one later and not be limited by java scope
		while (true) {
			System.out.println("Please make a choice:");
			System.out.println("1 		- a built in Polynomial");
			System.out.println("2 		- a Polynomial read from 'polynomials.txt'");
			System.out.println("<polynomial> 	- enter your own polynomial eg '2x3+3x7' whish is 2x to the power of 3 plus etc.");
			System.out.println("exit 		- Quits the program");
			System.out.print("choice:");
			String choice = myInput.next();						//get input
			if (choice.equals("1")){
				choice = "12x9+5x6+13x5+4x4+2x3+11x2-6";		//1st polynomial in the outline
				poly = new Polynomials(choice);					//create it
			} else if (choice.equals("2")){
				poly = readPolynomialsFile("polynomials.txt");	//2nd polynomial in outline made from file
			} else if (choice.equals("exit")){
				System.out.println("Thankyou for using this program.");
				myInput.close();								//close resources and exit loop
				return;
			} else {
				poly = new Polynomials(choice);					//make user's own polynomial
			}
			System.out.println("\n" + choice + " <-- Using Polynomial (2 = file used).");	//result on left, description on right
			System.out.println(poly + " 	<-- LinkedList.");
			System.out.println(poly.add(poly) + " 	<-- The result of a polynomial add (add it self together).");
			System.out.println(poly.getValue(2) + " <-- The value of the polynominal given (x = 2).");
			System.out.println(productOf(poly, poly) + " <-- The product of two polynomials (itself agin).");
			System.out.println(poly.getDerivative() + " 	<-- The Derivative of a polynomial (where ax^k -> akx^k-1).");
			System.out.println(poly.insertTerm("2x4") + "	<-- The polynomial when 2x4 is inserted (but also added and sorted).");
			System.out.println("\nPress Enter to continue.");
			myInput.nextLine(); //2x - 1st - grabs the "already entered" input
			myInput.nextLine();	//2nd - so now we can now grab the "enter key"
		}
	}
}

/* This is a custom redundant sorting algorithm i spent a few hours on 
 * but then remembered comparable which i did also have some difficulty on.
 * this works by rebuilding itself by adding and removing nodes.
//sorting it
int highestIndex = -1;
int size = size();
for (int i = 0; i < size; i++){
	int highestValue = Integer.MIN_VALUE;
	int i2 = 0;
	while (i2 < size()) {
		Node myNode = get(i2);
		if (myNode.num2 > highestValue){
			highestValue = myNode.num2;
			highestIndex = i2;
		}
		i2++;
	}
	this.add(get(highestIndex));
	remove(highestIndex);
	highestIndex = -1;
}//*/