import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

// File: Graph.java from the package EDU.xorado.graphs
// Complete documentation is available from the Graph link in
//   http://www.cs.xorado.edu/~main/docs/


/******************************************************************************
* A Graph is a labeled graph with a finite number of vertices.
*
* @author Joshua Graham, modified from Michael Main Graph Class
* 
* @version 2.0 
* unsolvable - maze hang
* - if (distance[target] > 0){ 
* maze numbering corrected
* - System.out.println("path: " + i2);
*
* @version
*   21, 5, 2014
******************************************************************************/
public class Graph {
   private int[][] edgeWeight;	//store the weights of each edge - in this case it's 1
   private boolean[][] edges; //is there an edge or not? (true/false) - adjacency matrix
   private Object[] labels;	//enter, exit, star? - put them here
   private java.util.ArrayList<String> maze = new java.util.ArrayList<String>(); //store the file input
   private int height;
   private int width;
   
   /**
   * Initialize a Graph with some vertices.
   * @param mazeFile
   *   The text file of vertices for this Graph
   * @precondition
   *   Ensure mazeFile actually has data, preferably at least 2 lines
   *@postcondition
   *   A graph is created with edges, weights and stars computed.
   * @exception OutOfMemoryError
   *   Shows there is insufficient memory for the number of vertices.
   **/   
   public Graph(String mazeFile){
	   int vertices = 0;	//initialisation
	   int y= 0;			//y is the vertical axis of the text document
	   String currentLine;
	   height = 0;			//height and weight are teh two numbers on top of the mazefile. It is the number of rows/coloumns of the graph/maze.
	   width = 0;
	   int weight = 1; //using weight of 1
	   try {
		   //read in a copy of the maze
		   File myFile = new File(mazeFile);		//create the object to get file input
		   Scanner myScanner = new Scanner(myFile);	//make scanner to get input
		   while (myScanner.hasNextLine()) {		//while there are lines to read
	        	currentLine = myScanner.nextLine();
	        	maze.add(currentLine); 				//make copy of maze for printing
		   }
		   myScanner.close();
		   
	        //build a graph and re-read the file
	        myScanner = new Scanner(myFile);
	        boolean heightSet = false;
	        while (myScanner.hasNextLine()) {			//while there are lines to read
	        	currentLine = myScanner.nextLine();
	        	int length = currentLine.length(); 		//get dimensions
	        	if (y== 0) {							//special algorithms for the edges. y is this the y axis
	        		for (int x = 0; x < length; x++){
	        			String letter = currentLine.substring(x, x + 1);	//get a character
	        			if (!letter.equals(" ")){ 							//not a space
	        				if (heightSet == false){						//to grab a double digits, we do some conditions.
	        					if (height != 0){
	        						height = Integer.parseInt(String.valueOf(height).concat(letter)); 		//grabs the numbers and combine if together,
	        					}else{
	        						height = Integer.parseInt(letter);
	        					}
	        				}else{
	        					if (width != 0){ 
	        						width = Integer.parseInt(String.valueOf(width).concat(letter));
	        					} else{
	        						width = Integer.parseInt(letter);
	        					}
	        				}
	        			}else{ //is a space
	        				heightSet = true;	//it's a space, so move to next number
	        			}
	        		}
	        		y= y + 1;
	        		myScanner.nextLine(); //skip next line
	        		vertices = height * width;					//setup the graphs
	        		edgeWeight = new int[vertices][vertices];
	        		edges = new boolean[vertices][vertices];  // All values are initially false
	        	    labels = new Object[vertices];     // All values are initially null
	        	}else{ //build graph
	        		for (int x = 0; x < length; x = x + 1){ //go through the line
	        			String letter = currentLine.substring(x, x + 1);
	        			//middle | | | |
	        			if (letter.equals(" ") || letter.equals("*")){ //maybe an edge?
	        				if (x == 0){ //left edge of maze - not an edge - entrance
	        					if (y== 2){ //2nd down
	        						this.setLabel(0, "start"); //first row  is 0
	        					} else {
	        						this.setLabel((y - 1) / 2 , "start");
	        					}
	        				} else { //edges		
	        					if (x %2 == 0){ //if even			 	 	
	        						if (y == 2){							
	        							int source = (x / 2) - 1;		// +-+-+
	        							int target = x  / 2;			// |<->|
	        							this.addEdge(source, target); 	// +-+-+
	        							this.setEdgeWeight(source, target, weight);
	        						} else {
	        							int row = (y / 2) - 1;
	        							int source = (row * width) + (x / 2) - 1;
	        							int target = (row * width) +  (x  / 2);
	        				        	this.addEdge(source, target);
	        				        	this.setEdgeWeight(source, target, weight);
	        						}
	        					}else { //odd - look for stars (treasure?)
	        						if (letter.equals("*")) {
	        							if (y == 2){
	        								if (x == 1){
	        									this.setLabel(0, "star");			//Do some calculation to find out where are are in relation to graph
	        								} else {
	        									this.setLabel((x - 1) / 2, "star");
	        								}	
	        							} else {
	        								int adjustment = width * ((y /2) - 1);
	        								this.setLabel(((x - 1) / 2) + adjustment , "star");
	        							}
	        						}
	        					}
	        				}
	        			}		
	        		}
	        		//top and bottom +-+-+-
       				y++;
       				currentLine = myScanner.nextLine(); //next line
       				for (int x = 1; x < length; x = x + 2){
	        			String letter = currentLine.substring(x, x + 1); //great a character
	        			if (letter.equals(" ")){ //maybe an edge?
	        				if (!myScanner.hasNext()) { //last line?
	        					int adjustment = width * (height - 1); //the number of previous rows
	        					if (x == 1){ //left side of maze
	        						this.setLabel((x - x) / 2 + adjustment, "target");		
	        					} else {
	        						this.setLabel(((x - 1) / 2) + adjustment , "target");
	        						
	        					}											//+-+
	        				} else { //edges								//|^|
	        					if (y == 3){ //second line					//+^+
        							if (x == 1){							//|^|
        								this.addEdge(0, width);				//+-+
        								this.setEdgeWeight(0, width, weight);
        							} else{
        								int target = (x -1) / 2;
        								int source = ((x -1) / 2) + width;
        								this.addEdge(source, target);
        								this.setEdgeWeight(source, target, weight);
        							}
	        					} else {
	        						int row = ((y - 1) / 2) -1;
        							int target = (row * width) +  ((x - 1) / 2) + width;
        							int source = (row * width) + ((x - 1) / 2);
        							this.addEdge(source, target);
        							this.setEdgeWeight(source, target, weight);
	        					}
	        				}
	       				}	
	        		}
	        	}
	        	y++;
	        }
	        myScanner.close();	//shutdown the resources used for file reading  
		} catch (FileNotFoundException e) {
			throw new NumberFormatException("A File error occured. Does it exist? \n" + e);	//ensure a file exist
		}
   }
   /**
    * Print a the Maze of the constructed Graph.
    * @param path
    *   An ArrayList of the path pre-computed.
    *@postcondition
    *   A maze is printed to screen.
    **/  
   private void printMaze (ArrayList<Integer> path){
	   char direction;
	   for (int i = 0; i < path.size(); i++){
		   //determine which "V" to use
		   if ((i + 1) == path.size()){ //last one is downwards, the exit is at the bottom
			   direction = "v".charAt(0);  
		   } else if ((path.get(i) - path.get(i + 1) == -width)){ //using the next direction, we calc where to go
			   direction = "v".charAt(0);
		   } else if ((path.get(i) - path.get(i + 1) == width)){
			   direction = "^".charAt(0);
		   } else if ((path.get(i) - path.get(i + 1) > 0)){
			   direction = "<".charAt(0);
		   } else {
			   direction = ">".charAt(0);
		   }
		   if (path.get(i) < this.width){
			   char[] charReplace = maze.get(2).toCharArray();		//change the maze text stored
			   if (path.get(i) == 0){
				   charReplace[1] = direction;
			   } else {
				   charReplace[(path.get(i) * 2) + 1] = direction;
			   }
			   maze.set(2, String.valueOf(charReplace));
		   } else {
			   int line = path.get(i) / width; //which line (needs adjust)
			   int col = path.get(i) % width; //which place in line (needs adjust)
			   char[] charReplace = maze.get((line * 2) + 2).toCharArray();
			   charReplace[(col * 2) + 1] = direction;
			   maze.set((line * 2) + 2, String.valueOf(charReplace));
		   }
	   }
	   //print the actual maze
	   for (int i = 0; i < maze.size(); i++){
		   System.out.println(maze.get(i));
	   }
   }
   
   /**
    * Initialize a Graph with n vertices,
    * no edges, and null labels.
    * @param source target weight
    *   Sets the weight for a given edge between source and target
    **/  
   
   public void setEdgeWeight(int source, int target, int weight) { //set the edges twice, as undirected graph
	   edgeWeight[source][target] = weight;
	   edgeWeight[target][source] = weight; 
   }
   
   /**
    * Grabs the weight for an edge
    * @param source target
    *   the two edges needed for the weight
    **/ 
   public int getEdgeWeight(int source, int target) {
	   return(edgeWeight[source][target]); 
   }
   
   /**
    * Computes the path from entry to exit
    * @param start target
    *   The entry and exit - ensure there actually is a path or program may loop forever.
    *@postcondition
    *   Path is made
    **/  
   public void getPath(int start, int target){
	   int [] distance = new int[this.size()];
	   final boolean [] visited = new boolean [this.size()];	//create some arrays for processing
	   int[] before = new int[this.size()];; 
	   for (int i=0; i < distance.length; i++) {
		   distance[i] = Integer.MAX_VALUE;			//max int means infinity
		   }
	   distance[start] = 0;		//init, start is zero, etc
	   before[start] = 0;
	   visited[start] = true;
	   
	   //shortest path for all
	   for (int i = 0; i < distance.length - 1; i++) {
		   int curnode=0; 					// This is our current node
		   int min = Integer.MAX_VALUE;		//set everything to max
		   
		   //find the vertice that's the closest
		   for(int j=0; j<this.size();j++){ // 
			   if(!visited[j] && distance[j]<min) { //if not visited  and is close
				   curnode=j;
				   min=distance[j];
				   if (j == target){	//we have reached the target node, no need to waste computing time with other nodes
					   break;
				   }
			   }
		   }
		   //ive now visited that node 
		   visited[curnode]=true;
		   for(int j=0; j<distance.length; j++){
				   if (distance[j] + edgeWeight[curnode][j] < distance[j]){ //can't solve unsolvables - didn't work or 10secs isn't long enough to wait. 
					   
					   // Our new estimate to get to j, going through vertex.
					   distance[j] = distance[curnode] + edgeWeight[curnode][j];	
					   before[j] = curnode;
				   }
		   }
	   }
	   if (distance[target] > 0){
		   final java.util.ArrayList<Integer> path = new java.util.ArrayList<Integer>();
	       int x = target;			//make a different order
	       while (x!=start) {
	          path.add (0, x);
	          x = before[x];
	       }
	       path.add (0, start);
	       printMaze(path);		//pass on for printing
	   }
   }
   /**
    * Computes the distance part of Dijnstra's Algorithm.
    * @param start target
    *   The two places to to be meausred.
    *@postcondition
    *   A path exists
    **/  
   
   public int getDistance(int start, int target){
	   int [] distance = new int[this.size()];
	   final boolean [] visited = new boolean [this.size()];	//the usual, same as above
	   for (int i=0; i < distance.length; i++) {				//no before variable, does not list making
		   distance[i] = Integer.MAX_VALUE;						//INFINITY is assumed
		   }
	   distance[start] = 0;		//init
	   visited[start] = true;
	   
	   //shortest path for all
	   for (int i = 0; i < distance.length - 1; i++) {
		   int curnode=0; // This is our current node
		   int min = Integer.MAX_VALUE;

		   //find the vertice that's the closest
		   for(int j=0; j<this.size();j++){ // 
			   if(!visited[j] && distance[j]<min) { //if not visited  and is close
				   curnode=j;
				   min=distance[j];
				   if (j == target){	//we have reached the target node, no need to waste computing time with other nodes
					   break;
				   }
			   }
		   }
		   //ive now visited that node 
		   visited[curnode]=true;
		   for(int j=0; j<distance.length; j++){
			   //System.out.println(distance[j]);
				   if (distance[j] + edgeWeight[curnode][j] < distance[j]){
					   // Our new estimate to get to j, going through vertex.
					   distance[j] = distance[curnode] + edgeWeight[curnode][j];
				   }
		   }
	   }	   
	return distance[target];	//here is the distane
   }
   
   /**
    * Get the numbers of stars counted during init.
    *@postcondition
    *   A number of stars is returned.
    **/  
   public int getStars(){
	   int stars = 0;
	   for (int i = 0; i < this.labels.length; i++){						//loop and count stars, not advised in reality ;)
		   if (this.labels[i] != null && this.labels[i].equals("star")){	//skip nulls so no error
			   stars++;
		   }
	   }
	return stars;
   }
   /**
    * Count destinations available
    *@postcondition
    *   ArrayList of destinations are returned.
    * @exception OutOfMemoryError
    *   Shows there is insufficient memory for the number of vertices.
    **/  
   
   public ArrayList<Integer> getTargets(){
	   java.util.ArrayList<Integer> targets = new java.util.ArrayList<Integer>();	//count targets, same as above almost
	   for (int i = 0; i < this.labels.length; i++){
		   if (this.labels[i] != null && this.labels[i].equals("target")){
			   targets.add(i);
		   }
	   }
	return targets;
   }
   /**
    * Get the amount of stars entry points counted.
    *@postcondition
    *   ArrayList of stars is returned
    **/  
   
   public ArrayList<Integer> getStarts(){											//more counting
	   java.util.ArrayList<Integer> starts = new java.util.ArrayList<Integer>();
	   for (int i = 0; i < this.labels.length; i++){
		   if (this.labels[i] != null && this.labels[i].equals("start")){
			   starts.add(i);
			   
		   }
	   }
	return starts;
   }

   /**
   * Adds an edge to this Graph or a maze.
   * @param source target
   *   The two vertices that is a edge between.
   * @precondition
   *   No negatives.
   * @postcondition
   *   edge added (or unchanged if already there).
   **/
   public void addEdge(int source, int target){
      edges[source][target] = true;	//do both - the graph is undirected
      edges[target][source] = true;
   }
   
   /**
   * Getter for the labels
   * @param vertex
   *   a vertex label, usually a string
   * @return
   *   the label of the specified vertex, in string same format, usually string
   **/
   public Object getLabel(int vertex){
      return labels[vertex];		//retrieve label
   }


   /**
   * Changes the  label.
   * @param vertex
   *   a vertex string
   * @param newLabel
   *   a new label - could be null
   * @postcondition
   *   Label changed.
   **/
   public void setLabel(int vertex, Object newLabel){
      labels[vertex] = newLabel;
   }   
   
   
   /**
   * Get teh number of vertices in graph
   * @return
   *   Number of vertices.
   **/ 
   public int size(){
      return labels.length;
   }
   
   /**
    * The main of the program. User gets some chooses and proceeds.
    *@postcondition
    *   Some data is outputted, at a menu.
    **/  
   public static void main(String[] args){
	   System.out.println("Welcome to Joshua Graham's Maze Program.");	//intro
	   System.out.println("Note: May not solve the solvables - probably loop forver or freeze.\n");	//intro
	   Scanner myInput = new Scanner(System.in);
	   Graph myGraph;
	   while (true) {	//loop forever until break
		   System.out.println("Please choose a maze file:");
		   System.out.println("1 		- maze01.mz");
		   System.out.println("2 		- maze02.mz");
		   System.out.println("3 		- maze03.mz");
		   System.out.println("<maze> 	- enter your own maze file name, such as 'maze04.mz'");
		   System.out.println("exit 	- Quits the program");
		   System.out.print("choice:");
		   String choice = myInput.next();					//get input
		   if (choice.equals("1")){
			   choice = "maze01.mz";						//1st maze
			   System.out.println("Creating maze from: " + choice + ".");
			   myGraph = new Graph(choice);					//create it
		   } else if (choice.equals("2")){
			   choice = "maze02.mz";		
			   System.out.println("Creating maze from: " + choice + ".");
			   myGraph = new Graph(choice);
		   } else if (choice.equals("3")){
			   choice = "maze03.mz";		
			   System.out.println("Creating maze from: " + choice + ".");
			   myGraph = new Graph(choice);	
		   } else if (choice.equals("exit")){
			   break;	//quit loop here.
		   } else {
			   myGraph = new Graph(choice);						//make user's own maze file
		   }
		   System.out.println("There are " + myGraph.getStarts().size() + " starting point(s).");	//some stats
		   System.out.println("There are " + myGraph.getTargets().size() + " ending point(s).");
		   int paths = myGraph.getStarts().size() * myGraph.getTargets().size();
		   System.out.println("A Combination of " + paths + " path(s).");
		   System.out.println("There are also " + myGraph.getStars() + " stars on this maze, however they will not be counted on the paths.");

			for (int i = 0; i < myGraph.getTargets().size(); i++) {			//loop through each path
				for (int i2 = 0; i2 < myGraph.getStarts().size(); i2++) {
					System.out.println("\nPress Enter to solve this/next path:");
					myInput.nextLine(); //2x - 1st - grabs the "already entered" input
					System.out.println("path: " + i2);
					int start = myGraph.getStarts().get(i2);
					int target = myGraph.getTargets().get(i);
					myGraph.getPath(start, target);
					System.out.println("We Traveled from " + myGraph.getStarts().get(i2) + " to " + myGraph.getTargets().get(i) + ".");
					System.out.println("The Distance was " + myGraph.getDistance(myGraph.getStarts().get(i2), myGraph.getTargets().get(i)) + ".");  
				}
			}
			System.out.println("\nAll Path(s) solved, please enter to continue.");
			myInput.nextLine();
	   }
	   myInput.close();
	   System.out.println("\nThankyou for using the Maze program.");  	//exit
   }       
}
           
